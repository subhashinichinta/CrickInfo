package com.crick.apis.entities;

public enum MatchStatus {

	LIVE,COMPLETED
}
