package com.crick.apis;



import java.util.List;

import org.apache.catalina.connector.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import com.crick.apis.entities.Match;

import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class CrickInformerBackendApplicationTests {

	@Autowired
	TestRepository matchRepo;
	
	
	
	private final RestTemplate restTemplate;
	
	@Autowired
    public CrickInformerBackendApplicationTests(RestTemplateBuilder builder) {
        this.restTemplate = builder.build();
    }

	
	
	
	@Test
	@Sql(statements = "insert into crick_matches (match_id,batting_team,batting_team_score,bowl_team,bowl_team_score,matchnumber_venue) values ('2','Newzealand','130','SA','250','hyderabad')",executionPhase=Sql.ExecutionPhase.BEFORE_TEST_METHOD)
	public void getLiveMatches() {
		
		 Match[] customerJson = restTemplate.getForObject("http://localhost:8082/match",Match[].class);
		 System.out.println("customerJson- "+customerJson.toString());
		 List<Match> matches = this.matchRepo.findAll();
		
		 System.out.println("successful - "+matches);
		 assertThat(matches).size().isGreaterThan(0);
	}
}
