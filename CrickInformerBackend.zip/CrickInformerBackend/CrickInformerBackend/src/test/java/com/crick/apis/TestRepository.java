package com.crick.apis;

import org.springframework.data.jpa.repository.JpaRepository;

import com.crick.apis.entities.Match;

public interface TestRepository extends JpaRepository<Match,Integer> {

}
